/*****************************************************************************
* Copyright(C) 2015 Samsung Software Membership SSM_24-1th_GoJiSeong
* All right reserved.
*
* File name	    : main.c
* Last version	: 1.00
* Description	: PIG project ���� �κ� ����
*
* History
* Date		    Version	    Author			Description
* 20/06/2015	1.00		oh woomin	    Created
*****************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "stm32f4xx.h"
#include "stm32f4xx_it.h"
#include "delay.h"
#include "stm32_systick.h"
#include "stm32_pwm.h"
#include "led.h"
#include "dc_moter.h"
#include "stm32_uart.h"
#include "stm32_encoder.h"
#include "stm32_ebimu.h"
#include "typedef.h"
#include "pid.h"
#include "Adc.h"
#include "ar1020.h"
#include "Packet.h"
#include "ParsingPacket.h"

#define K_P          1.0
#define K_I           0.0
#define K_D          0.8

extern __IO uint16_t ADCConvertedValue[3];
u8 oscill[1000] = "1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111";

////////////����ü ����//////////
Moter_type motor;
Encoder_type encoder;
Moter_rpm_type rpm_type;
Pid_type pid_set;

ReceivePacket BuleData;
ReceivePacket OscillData;

EbimuPacketType parsing;
/////////////////////////////////

int char_to_int(char *array)
{
  int r = 0x00;
  r |= array[0] << 24;
  r |= array[1] << 16;
  r |= array[2] << 8;
  r |= array[3];
  return r;
}

int main(void)
{
  ///////////���� ����/////////////
  int MotorState = 0;
  int MotorRpm = 0;
  int SetRpm = 0;
  int PidOut = 0;
  int PidSum = 0;
  int SetGear = 0;;
  int SetPluse = 0;;
  
  float SetP;
  float SetI;
  float SetD ;  
  
  float *P;
  float *I;
  float *D;
  int tempP;
  int tempI;
  int tempD;
  
  int pwm1Hz;
  int pwm1Du;
  int pwm2Hz;
  int pwm2Du;
  
  
  int AdcState[2] = {0,};
  
  int UsartState = 0; 
  int UsartBand[5] = {9600,19200,57600,115200,230400};
  char tempArr[10][10];
  
  char slaveAdd;
  char slaveRe;
  u8 i2cData;
  char i2cSize;
  int i2cWork[30];
  int i2cStack=0;
  int i2cState=0;
  
  int oscill_state=0;
  char oscill_data[201]={0,};
  int oscill_stack=0;
  /////////////////////////////////
  
  ///////����� �ʱ�ȭ �Լ�////////
  PWM_timer1_init(10000);
  
  UART_init(Uart4, 115200); 
  UART_init(UART1, 115200); 
  UART_init(UART3, 115200);
  
  DC_moter_init(&motor);
  Encoder_init(&encoder);
  Pid_init(K_P,K_I,K_D,&pid_set);
  
  LED_init();
  LH_init();
  event.time = 1;
  Systick_init(1000000);
  
  //I2C_PortInit(100000);
  
  AdcInit ();
  
  PacketInit(&BuleData);
  
  ParsingPacket_Config(&parsing);
  /////////////////////////////////
  PWM_timer1_output(3,0); 
  PWM_timer1_output(4,500);
  
  motor.direction=Moter_forward;
  motor.speed = 0;
  
  
  UART4_printf("URAT4 TestBoard\n");
  UART3_printf("URAT3 TestBoard\n");
  UART1_printf("URAT1 TestBoard\n");
  
  DC_moter_control(motor);
  oscill_data[150] = 255;
  
  while(1)
  {   
    if(BluePacket(&BuleData)){
      
      //�����Ͱ� �� ��� ������
      if(BuleData.complete){
	 
	if(BuleData.buffer[0] == MODE_ADC){
	  memset(AdcState,0,sizeof(AdcState));
	  AdcState[(BuleData.buffer[1])] = 1;
	}
	
	else if(BuleData.buffer[0] == MODE_PWM){
	  pwm1Hz = 0;
	  pwm1Du = 0;;
	  pwm2Hz = 0;
	  pwm2Du = 0;
	  if(BuleData.buffer[1] == 1){
	    pwm1Hz = char_to_int(BuleData.buffer+2);
	    pwm1Du = BuleData.buffer[6]*10;
	    PWM_timer1_init(pwm1Hz);
	  }
	  else if(BuleData.buffer[1] == 2){
	    pwm2Hz = char_to_int(BuleData.buffer+2);
	    pwm2Du = BuleData.buffer[6]*10;
	    PWM_timer1_init(pwm2Hz);
	  }
	  
	  PWM_timer1_output(3,pwm1Du); 
	  PWM_timer1_output(4,pwm2Du);
	  
	}
	else if(BuleData.buffer[0] == MODE_USART){
	  
	  
	  if(BuleData.buffer[1] == 5){
	    int i;   
	    for(i=2; i<BuleData.BufferCount-1;i++)
	    {
	      UART3_putchar(BuleData.buffer[i]);
	    }
	  }
	  else{
	    UART_init(UART3, UsartBand[BuleData.buffer[1]]);    //
	    parsing.st = BuleData.buffer[2]+1;
	    parsing.end = BuleData.buffer[3]+1;
	    parsing.divide = BuleData.buffer[4];
	    parsing.num = BuleData.buffer[5]-48;
	    UsartState = 1;
	  }
	 
	}
	
	else if(BuleData.buffer[0] == MODE_I2C){
	  slaveAdd = BuleData.buffer[1];
	  slaveRe = BuleData.buffer[2];
	  i2cData = BuleData.buffer[3];
	  i2cSize = BuleData.buffer[4];
	  i2cState = 1;
	}
	else if(BuleData.buffer[0] == MODE_MOTOR){
	  //P�� �����
	  tempP = char_to_int(BuleData.buffer+1); 
	  P  = (float*) &tempP;
	  SetP = *P; 
	  tempI = char_to_int(BuleData.buffer+5); 
	  I  = (float*) &tempI;
	  SetI = *I; 
	  tempD = char_to_int(BuleData.buffer+9); 
	  D  = (float*) &tempD;
	  SetD = *D; 
	  SetRpm = char_to_int(BuleData.buffer+13); 
	  SetGear = char_to_int(BuleData.buffer+17); 
	  SetPluse = char_to_int(BuleData.buffer+21); 
	  // UART3_printf("%f %f %f %d %d %d\n" , *P ,*I ,*D,SetRpm,SetGear,SetPluse);
	  MotorState = 1;
	  Pid_init(SetP,SetI,SetD,&pid_set);
	}
	
	else if(BuleData.buffer[0] == MODE_HIGHLOW){
	  if(BuleData.buffer[1]  == 0){   
	    if(BuleData.buffer[2] == 0 ){
	      LH1_off();
	    }
	    else{
	      LH1_on();
	    }
	  }
	  if(BuleData.buffer[1]  == 1){
	    LED1_toggle();
	    if(BuleData.buffer[2] == 0 ){
	      LH2_off();
	    }
	    else{
	      LH2_on();
	    }
	  }
	  
	}
	else if(BuleData.buffer[0] == MODE_OSCILL){
	  oscill_state = 1;
	  //LED1_toggle();
	  UART_init(UART3, 115200);
	}
	
	else if(BuleData.buffer[0] == MODE_RESET){
	  //���� �ʱ�ȭ
	  memset(AdcState,0,sizeof(AdcState));
	  UsartState = 0;
	  i2cState = 0;
	  MotorState = 0;
	  LH1_off();
	  LH2_off();
	  SetRpm = 0;
	  SetGear = 0;
	  SetPluse = 0;
	  SetP = 0;
	  SetI = 0;
	  SetD = 0;
	  pwm1Hz = 0;
	  pwm1Du = 0;;
	  pwm2Hz = 0;
	  pwm2Du = 0;
	  PWM_timer1_output(3,pwm1Du); 
	  //PWM_timer1_output(4,pwm2Du);
	  oscill_state = 0;
	  motor.speed = 0;
	  DC_moter_control(motor);
	}
	
	BuleData.complete = 0;
	
      }
    }
    
    
    if(UsartState == 1){
      
      if(ParsingPacket(&parsing)){ 
	if(parsing.complete){
	  if(Parsing(parsing.buffer,&parsing))
	  {    
	    UART1_printf("%d\n",parsing.data[parsing.num]);
	  }
	  parsing.complete = 0;
	}
      }
    }
    
     if(i2cState)
      {
	if(ParsingPacket(&parsing)){ 
	  if(parsing.complete){
	    if(Parsing(parsing.buffer,&parsing))
	    {
	      if(slaveRe == 0x32)
		 UART1_printf("%d\n",parsing.data[0]);
	      else if(slaveRe == 0x34)
		 UART1_printf("%d\n",parsing.data[1]);
	      else if(slaveRe == 0x36)
		 UART1_printf("%d\n",parsing.data[2]);
	      else if(slaveRe == 0x38 )
		 UART1_printf("%d\n",parsing.data[3]);
	      else if(slaveRe == 0x3A)
		 UART1_printf("%d\n",parsing.data[4]);
	      else if(slaveRe == 0x3C)
		 UART1_printf("%d\n",parsing.data[5]);
	      else if(slaveRe == 0x3E)
		 UART1_printf("%d\n",parsing.data[6]);
	      else if(slaveRe == 0x40)
		 UART1_printf("%d\n",parsing.data[7]);
	    }
	    parsing.complete = 0;
	  }
	}
      }
    
    if(event.systick)
    {
     
      oscill_data[oscill_stack++]=abs(ADCConvertedValue[2]-48900) / 320;
      oscill_data[oscill_stack++]=( abs(ADCConvertedValue[2]-48900)  % 320) / 32;
      if(oscill_stack == 200)
	oscill_stack=0;
      event.systick = 0;
    }
    
    if(event.systick_10ms)
    {
      LED2_toggle();
     // UART3_printf("%d\n", ADCConvertedValue[2]);
      //UART3_printf("%s\n", "123");
      event.systick_10ms = 0;
    }
    
    if(event.systick_100ms)
    {
      if(oscill_state){
	int i;
      	 for(i=0;i<200;i++)
	{
	  UART3_putchar(oscill_data[i]);
	}
      }
  	
	
      if(AdcState[0] == 1){
	UART1_printf("%d\n",ADCConvertedValue[0]);
      }
      if(AdcState[1]== 1){
	UART1_printf("%d\n",ADCConvertedValue[1]);
      }
      //UART3_printf("%s",oscill_data);
      //UART3_printf("%s","111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111");

      /////////PID////////
      if(MotorState){
	
	Encoder_read(&encoder);
	MotorRpm = DC_motor_rpm(Rpm_100ms ,encoder.en_count, rpm_type);
	
	PidOut = Pid_control(SetRpm,MotorRpm ,&pid_set);
	PidSum += PidOut;
	if(PidSum > 900) PidSum = 900;
	else if(PidSum < 0) PidSum = 0;
	
	motor.speed = PidSum;
	DC_moter_control(motor);
	UART1_printf(" %d\n",MotorRpm);
	encoder.en_count = 0;
      }
      
      ///////////////////
      
     
      
      //////////����////////
      //UART3_printf("%s\n", oscill);
      // UART4_printf(" adc1 : %d\n", ADCConvertedValue[2]);
      ///////////////////////
      
      LED3_toggle();
      event.systick_100ms = 0;
    }   
  }
}