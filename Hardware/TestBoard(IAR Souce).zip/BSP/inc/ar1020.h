
#ifndef __AR1020_H
#define __AR1020_H

/* Defines -------------------------------------------------------------------*/
#define AR1020_ADDR    0x9A

#define AR1020_IRQ_PERIPH       RCC_AHB1Periph_GPIOA
#define AR1020_IRQ_BIT          GPIO_Pin_5
#define AR1020_IRQ_PORT         GPIOA

/* Function prototypes -------------------------------------------------------*/
void AR1020_Init(void);
void I2C_PortInit(int speed);
ErrorStatus AR1020_Write(u8 SlaveAddr, int NumByteToWrite, u8 *buffer);
ErrorStatus AR1020_Read(u8 SlaveAddr, int NumByteToRead, u8 *buffer);

int i2c_read(u8 addr, u8 reg, u8 *data);

#endif
