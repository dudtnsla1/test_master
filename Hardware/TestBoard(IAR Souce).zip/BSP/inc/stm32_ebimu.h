typedef struct
{
    char data[50];
    int start; 
    int count;
}Ebimu_type;

void Ebimu_init(Ebimu_type* ebimu);
ErrorStatus Ebimu_packet(Ebimu_type* ebimu);