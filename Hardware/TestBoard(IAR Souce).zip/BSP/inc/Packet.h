/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : packet.c
* Last version	: 1.00
* Description	: This file is header file for packet receive, transmit function
*
* History
* Date		    Version	    Author			Description
* 04/06/2010	1.00	    oh woomin	    created
*****************************************************************************/

/* Exported constants --------------------------------------------------------*/
#define MAX_BUFFER_LENGTH       200
#define MAX_RX_LENGTH           MAX_BUFFER_LENGTH/2-1
#define MAX_TX_LENGTH           200
#define MODE_ADC                 1
#define MODE_PWM                 2
#define MODE_USART               3
#define MODE_I2C                 4
#define MODE_MOTOR               5
#define MODE_HIGHLOW             6
#define MODE_RESET               7
#define MODE_OSCILL              8


/* Exported types ------------------------------------------------------------*/
typedef struct
{
    u8 start,complete;    
    u8 data[MAX_RX_LENGTH];    
    int BufferCount, BufferLength, DataLength;
    char buffer[MAX_BUFFER_LENGTH];
    
}ReceivePacket;

typedef struct
{
    u8 command;    
    int length;
    u8 data[MAX_TX_LENGTH];
}TransmitPacket;

/* Exported functions ------------------------------------------------------- */
void PacketInit(ReceivePacket *packet);
int BluePacket( ReceivePacket *packet);
int OscillPacket(ReceivePacket *packet);
int Usart2Packet(ReceivePacket *packet);