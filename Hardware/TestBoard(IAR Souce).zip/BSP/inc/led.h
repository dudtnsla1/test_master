/*****************************************************************************
* Copyright(C) 2013 Dong-A University MICCA_25th-GoJiSeong
* All right reserved.
*
* File name	    : led.h
* Last version	: 1.00
* Description	: This file contains definitions for STM32E_Module led_port resources
*
* History
* Date		    Version	    Author			Description
* 01/11/2013	1.00		oh woomin	    Created
*****************************************************************************/

#ifndef __PLATFORM_CONFIG_H
#define __PLATFORM_CONFIG_H

#define LED_periph    RCC_AHB1Periph_GPIOE
#define LED_port      GPIOE
#define LED1_pin      GPIO_Pin_10
#define LED2_pin      GPIO_Pin_11
#define LED3_pin      GPIO_Pin_12

#define LED1_on()     (LED_port->BSRRL = LED1_pin);
#define LED1_off()    (LED_port->BSRRH = LED1_pin);
#define LED1_toggle() (LED_port->ODR ^= LED1_pin);
#define LED2_on()     (LED_port->BSRRL = LED2_pin);
#define LED2_off()    (LED_port->BSRRH = LED2_pin);
#define LED2_toggle() (LED_port->ODR ^= LED2_pin);
#define LED3_on()     (LED_port->BSRRL = LED3_pin);
#define LED3_off()    (LED_port->BSRRH = LED3_pin);
#define LED3_toggle() (LED_port->ODR ^= LED3_pin);

#define LH_periph    RCC_AHB1Periph_GPIOB
#define LH_port      GPIOB
#define LH1_pin      GPIO_Pin_14
#define LH2_pin      GPIO_Pin_15


#define LH1_on()     (LH_port->BSRRL = LH1_pin);
#define LH1_off()    (LH_port->BSRRH = LH1_pin);
#define LH2_on()     (LH_port->BSRRL = LH2_pin);
#define LH2_off()    (LH_port->BSRRH = LH2_pin);

#endif

void LED_init(void);
void LH_init(void);