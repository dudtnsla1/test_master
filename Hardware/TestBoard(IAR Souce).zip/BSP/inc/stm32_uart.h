/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : stm32_uart.h
* Last version	: 2.00
* Description	: This file is header file for uart function.
*
* History
* Date		    Version	    Author			Description
* 03/06/2011	2.00		oh woomin	    ver2.0 create
*****************************************************************************/

#ifndef STM32_UART_H
#define STM32_UART_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "queue.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
#define UART1           1
#define UART2           2
#define UART3           3
#define Uart4           4
#define BUFFER_SIZE     256

/* Exported variables ---------------------------------------------------------*/
extern QueueType Uart1RxQueue, Uart2RxQueue, Uart4RxQueue , Uart3RxQueue;
extern QueueType Uart1TxQueue, Uart2TxQueue, Uart4TxQueue , Uart3TxQueue;

/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
void UART_init(u8 uart,u32 baud);

ErrorStatus UART1_putchar(const char ch);
ErrorStatus UART1_getchar(char *ch);
void UART1_putstr(char *string);
void UART1_printf(const char *fmt,...);

ErrorStatus UART2_putchar(const char ch);
ErrorStatus UART2_getchar(char *ch);
void UART2_putstr(char *string);
void UART2_printf(const char *fmt,...);

ErrorStatus UART4_putchar(const char ch);
ErrorStatus UART4_getchar(char *ch);
void UART4_putstr(const char *string);
void UART4_printf(const char *fmt,...);

ErrorStatus UART3_putchar(const char ch);
ErrorStatus UART3_getchar(char *ch);
void UART3_putstr(char *string);
void UART3_printf(const char *fmt,...);
#endif
