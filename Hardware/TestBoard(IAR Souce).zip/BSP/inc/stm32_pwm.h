
void PWM_timer3_init(int frequency);
void PWM_timer3_output(int ch, int value);
void PWM_timer5_init(int frequency);
void PWM_timer5_output(int ch, int value);
void PWM_timer1_init(int frequency);
void PWM_timer1_output(int ch, int value);
void PWM_timer8_init(int frequency);
void PWM_timer8_output(int ch, int value);