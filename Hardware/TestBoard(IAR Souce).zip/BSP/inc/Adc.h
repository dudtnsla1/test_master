#define ADC1_DR_ADDRESS    ((uint32_t)0x4001204C)
#define ADC3_DR_ADDRESS    ((uint32_t)0x4001224C)

void AdcInit (void);