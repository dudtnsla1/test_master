
/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"

/* Exported constants --------------------------------------------------------*/
#define MAX_EBIMU_LENGTH        256

/* Exported types ------------------------------------------------------------*/
typedef struct
{
    u8 start, complete;    
    int count, length;
    char buffer[MAX_EBIMU_LENGTH];
    int data[MAX_EBIMU_LENGTH];
    char st;
    char end;
    char divide;
    int num;

}EbimuPacketType;                       

/* Function prototypes -------------------------------------------------------*/
void ParsingPacket_Config(EbimuPacketType *packet);
ErrorStatus ParsingPacket(EbimuPacketType *packet);
ErrorStatus Parsing(char *string, EbimuPacketType *packet);