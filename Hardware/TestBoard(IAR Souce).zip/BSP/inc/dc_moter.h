#define DC_periph       RCC_AHB1Periph_GPIOA
#define DC_en_pin       GPIO_Pin_5
#define DC_en_port      GPIOA
#define DC_moter_on()   (GPIOA->BSRRL = DC_en_pin)
#define DC_moter_off()  (GPIOA->BSRRH = DC_en_pin)

#define Moter_stop	  0
#define Moter_forward	  1
#define Moter_back   	  2

#define Moter_right	  1
#define Moter_left        2

#define Rpm_1ms         0
#define Rpm_10ms        1
#define Rpm_100ms       2
#define Rpm_500ms       3

#define Motor_clk       52
#define Motor_gear      125

typedef struct
{
  unsigned char channel;
  unsigned int direction;
  int speed; 
}Moter_type;


typedef struct
{
  unsigned char time;
  unsigned int sec1_motor_revolution,min1_motor_revolution;
  unsigned int sec1_en_count;
  unsigned int motor_rpm;
  
}Moter_rpm_type;

void DC_port_init(void);
void DC_moter_init(Moter_type* motor);
void DC_moter_control(Moter_type moter);
int DC_motor_rpm(int time,int en_count, Moter_rpm_type moter_rpm);