
typedef struct
{
    int first_count;
    int last_count;
    int en_count;
}Encoder_type;

void Encoder_port_init (void);
void Encoder_init (Encoder_type* motor);
void Encoder_read (Encoder_type* encoder);