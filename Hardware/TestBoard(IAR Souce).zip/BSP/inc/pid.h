
#ifndef __PID_H
#define __PID_H

#include "stdint.h"

/*! \brief PID Status
 *
 * Setpoints and data used by the PID control algorithm
 */
typedef struct PID_DATA{
    int16_t lastProcessValue;
    int32_t sumError;

    float P_Factor;
    float I_Factor;
    float D_Factor;

    int32_t maxError;
    int32_t maxSumError;
} Pid_type;

/*! \brief Maximum values
 *
 * Needed to avoid sign/overflow problems
 */
// Maximum value of variables
#define MAX_P_TERM          INT16_MAX
#define MAX_I_TERM          INT16_MAX
#define MAX_PID_TERM        INT16_MAX

void Pid_init(float p_factor, float i_factor, float d_factor, Pid_type *pid);
int16_t Pid_control(int16_t setPoint, int16_t processValue, Pid_type *pid_st);

#endif
