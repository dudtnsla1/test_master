#include <stdio.h>
#include <string.h>
#include "stm32f4xx.h"
#include "stm32f4xx_it.h"
#include "stm32_uart.h"
#include "stm32_ebimu.h"

#define LF	0x0A
#define CR	0x0D

void Ebimu_init(Ebimu_type* ebimu)
{
    ebimu->start = 0;
    ebimu->count = 0;
    UART_init(4, 115200);
}

ErrorStatus Ebimu_packet(Ebimu_type* ebimu)
{
    char recive_data;
  
    if(UART4_getchar(&recive_data))
    {
        if(recive_data == '*')
        {
            ebimu->start = 1;
            ebimu->count = 0;
        }
        
        else if(recive_data == LF)
        {
            if(ebimu->data[ebimu->count-1] == CR) 
            {
                ebimu->start = 0;
                return SUCCESS;
            }
        }
        
        else
        {
            if(ebimu->start == 1)
            {
                ebimu->data[ebimu->count] = recive_data;
                ebimu->count++;
            }
        }
    } 
    
    return ERROR;
}