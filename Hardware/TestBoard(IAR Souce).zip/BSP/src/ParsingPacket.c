#include <string.h>
#include <stdio.h>
#include "stm32f4xx.h"
#include "stm32_uart.h"
#include "ParsingPacket.h"


/* Privated defines --------------------------------------------------------*/
#define LF				    0x0A
#define CR				    0x0D

void ParsingPacket_Config(EbimuPacketType *packet)
{  
    packet->complete = 0;
    packet->start = 0;
    packet->count = 0;
    packet->length = 0;
    packet->st = '$';
    packet->end = LF;
    packet->divide = ',';
    packet->num = 0;
}

ErrorStatus ParsingPacket(EbimuPacketType *packet)
{
	char RcvChar;
    
    // ���� ���ſ��� Ȯ��
    if(UART3_getchar(&RcvChar) == ERROR) return ERROR;       
    //UART4_printf("%c" ,RcvChar);
    // ��Ŷ ���۹��� ����
    if(RcvChar == '$')
    {
        packet->complete = 0;        
        packet->count = 0;
        packet->length = 0;
        packet->start = 1;            
    }
    // ��Ŷ ���Ṯ�� ����
    else if((RcvChar == LF))
    {
        if(packet->start)
        {
            packet->length = packet->count - 1;
            packet->complete = 1;
            packet->start = 0;
            packet->buffer[packet->count] = '\0';            
        }
        else return ERROR;
    }
    // Frame Data ����
    else
    {
        if(packet->start)
        {
            packet->buffer[packet->count++] = RcvChar;
        }
        else return ERROR;
    }    
    
    return SUCCESS;
}
    
ErrorStatus Parsing(char *string, EbimuPacketType *packet)
{
    char *parsing = NULL;
    char buffer[100];
    int stack=0;
    strcpy(buffer, string);
    
    parsing = strtok(buffer, ",");
    if(parsing != NULL)
    {
        sscanf(parsing, "%d", &packet->data[stack++]);
    }
    while(parsing)
    {
      parsing = strtok(NULL, ",");
      if(parsing != NULL)
      {
         sscanf(parsing, "%d", &packet->data[stack++]);
      }
    }

    return SUCCESS;
}