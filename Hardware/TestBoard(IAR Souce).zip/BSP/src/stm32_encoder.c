#include "stm32_encoder.h"
#include "stm32f4xx.h"
#include "stm32f4xx_it.h"
#include "stm32_uart.h"
#include "dc_moter.h"
#include <math.h>
#include <stdlib.h>
#include "stm32_uart.h"

extern Moter_type motor;


void Encoder_port_init (void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    /* TIM3, TIM4 clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);        
    /* GPIOA, GPIOD clock enable */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    
    /* TIM3 chennel2 configuration : PA.06, PA.07 */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    /* Connect TIM pin to AF2 */
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource6, GPIO_AF_TIM3);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource7, GPIO_AF_TIM3);
}

void Encoder_init (Encoder_type* motor)
{
    Encoder_port_init();
    motor->first_count = 0;
    motor->last_count = 0;
    motor->en_count = 0;
    
    TIM_SetAutoreload(TIM3, 0xFFFF);
    TIM_EncoderInterfaceConfig(TIM3, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);
    TIM_Cmd(TIM3, ENABLE);

}

void Encoder_read (Encoder_type* encoder)
{
    static int direction;
    

    encoder->first_count = TIM_GetCounter(TIM3);
    direction = motor.direction;
     
    
    if(direction == Moter_back)
    {
        if(encoder->first_count > encoder->last_count)
        {
            encoder->en_count = encoder->first_count - encoder->last_count;
        }
        else if(encoder->first_count < encoder->last_count)
        {
            encoder->en_count = (0xFFFF - encoder->last_count) + encoder->first_count;        
        }
        else
        {
            encoder->en_count = 0; 
        }
    }
    else if(direction == Moter_forward)
    {
        if(encoder->first_count < encoder->last_count)
        {
            encoder->en_count = encoder->last_count - encoder->first_count;
        }
        else if(encoder->first_count > encoder->last_count)
        {
            encoder->en_count = (0xFFFF - encoder->first_count) + encoder->last_count;        
        }
        else
        {
            encoder->en_count = 0; 
        }
    }   
    encoder->last_count = encoder->first_count;
    
}