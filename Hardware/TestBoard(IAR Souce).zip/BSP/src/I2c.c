/*****************************************************************************
* Copyright(C) 2015 Dong-A University MICCA _25th_GoJiSeong
* All right reserved.
*
* File name	    : main.c
* Last version	: 1.00
* Description	: TestBoard Ȯ�� 
*
* History
* Date		    Version	    Author			Description
* 02/03/2015	1.00		oh woomin	    Created
*****************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "I2c.h"


void delay_us(vu32 nCount)
{
    nCount *= 14; 
    for(; nCount!=0; nCount--) 
    {
        asm(" NOP ");          
        asm(" NOP ");      
    }
}
void i2c_init(unsigned int Speed)
{
    I2C_InitTypeDef  I2C_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);     
    
    GPIO_InitTypeDef GPIO_InitStructure;
    //Configure I2C1 pins: SCL and SDA
    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6| GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    //I2C1 and I2C1 Periph clock enable
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);
    
    I2C_DeInit(I2C1);    
    
    //I2C1 configuration
    I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
    I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
    I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
    I2C_InitStructure.I2C_OwnAddress1 = 0x00;
    I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
    I2C_InitStructure.I2C_ClockSpeed = Speed;
    I2C_Cmd(I2C1, ENABLE);
    I2C_Init(I2C1, &I2C_InitStructure);
}

int i2c_write(u8 addr, u8 reg, u8 data)
{
    __IO uint32_t temp = 0, Timeout = 0;
          
    Timeout = 0xFFFF;    
    /* Send START condition */
    I2C1->CR1 |= CR1_START_Set;
    /* Wait until SB flag is set: EV5 */
    while ((I2C1->SR1&0x0001) != 0x0001)
    {
        if (Timeout-- == 0) return 0;
    }
    
    /* Send the slave address */
    I2C1->DR = addr & OAR1_ADD0_Reset;
    Timeout = 0xFFFF;
    /* Wait until ADDR is set: EV6 */
    while ((I2C1->SR1 &0x0002) != 0x0002)
    {
        if (Timeout-- == 0) return 0;
    }    
    
    /* Clear ADDR flag by reading SR2 register */
    temp = I2C1->SR2;
    /* Write the first data in DR register (EV8_1) */
    I2C1->DR = reg;            
    /* EV8_2: Wait until BTF is set before programming the STOP */
    while ((I2C1->SR1 & 0x00004) != 0x000004);
    
    /* Clear ADDR flag by reading SR2 register */
    temp = I2C1->SR2;
    /* Write the first data in DR register (EV8_1) */
    I2C1->DR = data;            
    /* EV8_2: Wait until BTF is set before programming the STOP */
    while ((I2C1->SR1 & 0x00004) != 0x000004);
    
    /* Send STOP condition */
    I2C1->CR1 |= CR1_STOP_Set;
    /* Make sure that the STOP bit is cleared by Hardware */
    while ((I2C1->CR1&0x200) == 0x200);       
    
    return 1;   
}

int i2c_read(u8 addr, u8 reg, u8 *data)
{
    int Timeout;    
    
    /* Enable Acknowledgement */
    I2C_AcknowledgeConfig(I2C1,ENABLE);
    
   /* Send START condition */
    I2C_GenerateSTART(I2C1, ENABLE);  
    /* Test on EV5 and clear it */
    Timeout = 0xFFFF;
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT))
    {
        if(Timeout-- == 0) return 0;
    }
    
    /* Send slave address for write */
    I2C_Send7bitAddress(I2C1, addr, I2C_Direction_Transmitter);
    /* Test on EV6 and clear it */
    Timeout = 0xFFFF;
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
    {
        if(Timeout-- == 0) return 0;
    }

    
    /* Send the internal address to write to */    
    I2C_SendData(I2C1, reg);
    /* Test on EV8 and clear it */
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED));    
    
    
    /* Send STRAT condition a second time */  
    I2C_GenerateSTART(I2C1, ENABLE);
    /* Test on EV5 and clear it */
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT));    
    
    /* Send device address for read */
    I2C_Send7bitAddress(I2C1, addr, I2C_Direction_Receiver);
    /* Test on EV6 and clear it */
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED));
    
    /* Test on EV7 and clear it */
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_RECEIVED));  
    /* Store received data on I2C1 */
    *data = I2C_ReceiveData(I2C1);            
    /* Disable Acknowledgement */
    I2C_AcknowledgeConfig(I2C1, DISABLE); 
    /* Send STOP Condition */
    I2C_GenerateSTOP(I2C1, ENABLE);   
    
    delay_us(100);
    
    return 1;     
    
}

int i2c_sum(u8 addr, u8 reg)
{
    int sum;
    unsigned char arr[8];
    int i;
    for(i=0;i<2;i++)
    {
        i2c_read(addr,reg+i,&arr[i]);
    }
    
    sum = arr[0] + (arr[1]<<8);
    return sum;
}

int StartCondition(void)
{
     int Timeout;    
    
    /* Enable Acknowledgement */
    I2C_AcknowledgeConfig(I2C1,ENABLE);
    
   /* Send START condition */
    I2C_GenerateSTART(I2C1, ENABLE);  
    /* Test on EV5 and clear it */
    Timeout = 0xFFFF;
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT))
    {
        if(Timeout-- == 0) return 0;
    }
    return 1;
}
int AddressWrite(u8 addr)
{
    int Timeout;
    /* Send slave address for write */
    I2C_Send7bitAddress(I2C1, addr, I2C_Direction_Transmitter);
    /* Test on EV6 and clear it */
    Timeout = 0xFFFF;
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
    {
        if(Timeout-- == 0) return 0;
    }
     return 1;
}

int Register(u8 reg)
{
    int Timeout;
    /* Send the internal address to write to */    
    I2C_SendData(I2C1, reg);
    Timeout = 0xFFFF;
    /* Test on EV8 and clear it */
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED))
    {
        if(Timeout-- == 0) return 0;
    }
    return 1;
}

int AddressRead(u8 addr)
{
    int Timeout;
    /* Send device address for read */
    I2C_Send7bitAddress(I2C1, addr, I2C_Direction_Receiver);
     Timeout = 0xFFFF;
    /* Test on EV6 and clear it */
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED))
    {
        if(Timeout-- == 0) return 0;
    }
    return 1;
}

int DataRead(u8 *data)
{
    int Timeout;
    Timeout = 0xFFFF;
    /* Test on EV7 and clear it */
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_RECEIVED))
    {
        if(Timeout-- == 0) return 0;
    }
    /* Store received data on I2C1 */
    *data = I2C_ReceiveData(I2C1);
    delay_us(100);
    return 1;
}

int StopCondition()
{
    /* Disable Acknowledgement */
    I2C_AcknowledgeConfig(I2C1, DISABLE); 
    /* Send STOP Condition */
    I2C_GenerateSTOP(I2C1, ENABLE);          
    
    return 1;
}


