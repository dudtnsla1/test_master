#include "stm32f4xx.h"
#include "stm32f4xx_it.h"
#include "stm32_pwm.h"
#include "dc_moter.h"
#include "stm32_pwm.h"
#include "stm32_uart.h"


void DC_port_init(void)
{
    GPIO_InitTypeDef GPIO_moter_set;
    
    RCC_AHB1PeriphClockCmd(DC_periph,ENABLE);
    
    GPIO_moter_set.GPIO_Pin = DC_en_pin;
    GPIO_moter_set.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_moter_set.GPIO_OType = GPIO_OType_PP;
    GPIO_moter_set.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_moter_set.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(DC_en_port, &GPIO_moter_set);
    
    DC_moter_on();
}

void DC_moter_init(Moter_type* motor)
{
    DC_port_init();
    PWM_timer5_init(40000);
    
    motor->channel    = Moter_right;
    motor->direction  = Moter_stop;
    motor->speed      = 0;
}

void DC_moter_control(Moter_type moter)
{
    
    if(moter.channel == Moter_right)
    {
        if(moter.direction == Moter_forward)
        {
            PWM_timer5_output(1,moter.speed); 
            PWM_timer5_output(2,0);
        }
        
        else if(moter.direction == Moter_back)
        { 
            PWM_timer5_output(1,0); 
            PWM_timer5_output(2,moter.speed);
        }
        
        else
        {
            PWM_timer5_output(1,0); 
            PWM_timer5_output(2,0);
        }
    }
    
    else if(moter.channel == Moter_left)
    {
        if(moter.direction == Moter_forward)
        {
            PWM_timer5_output(3,0); 
            PWM_timer5_output(4,moter.speed);
        }
        
        else if(moter.direction == Moter_back)
        { 
            PWM_timer5_output(3,moter.speed); 
            PWM_timer5_output(4,0);
        }
        
        else
        {
            PWM_timer5_output(0,0); 
            PWM_timer5_output(4,0);
        }
    }
    
}

int DC_motor_rpm(int time,int en_count, Moter_rpm_type moter_rpm)
{
			
	if(time == Rpm_1ms)
	{
		moter_rpm.sec1_en_count = (en_count * 1000); 
		moter_rpm.sec1_motor_revolution = (moter_rpm.sec1_en_count / Motor_clk);
		moter_rpm.min1_motor_revolution = (moter_rpm.sec1_motor_revolution * 60);
		moter_rpm.motor_rpm = (moter_rpm.min1_motor_revolution / Motor_gear);
		return moter_rpm.motor_rpm;
	}
	
	else if(time == Rpm_10ms)
	{
		moter_rpm.sec1_en_count = (en_count * 100); 
		moter_rpm.sec1_motor_revolution = (moter_rpm.sec1_en_count / Motor_clk);
		moter_rpm.min1_motor_revolution = (moter_rpm.sec1_motor_revolution * 60);
		moter_rpm.motor_rpm = (moter_rpm.min1_motor_revolution / Motor_gear);
        //UART1_printf("%d//%d//%d//%d\n",moter_rpm.sec1_en_count ,moter_rpm.sec1_motor_revolution, moter_rpm.min1_motor_revolution, moter_rpm.motor_rpm);
		return moter_rpm.motor_rpm;
	}
		
	else if(time == Rpm_100ms)
	{
		moter_rpm.sec1_en_count = (en_count * 10); 
		moter_rpm.sec1_motor_revolution = (moter_rpm.sec1_en_count / Motor_clk);
		moter_rpm.min1_motor_revolution = (moter_rpm.sec1_motor_revolution * 60);
		moter_rpm.motor_rpm = (moter_rpm.min1_motor_revolution / Motor_gear);
		return moter_rpm.motor_rpm;
	}
	
	else if(time == Rpm_500ms)
	{
		moter_rpm.sec1_en_count = (en_count * 2); 
		moter_rpm.sec1_motor_revolution = (moter_rpm.sec1_en_count / Motor_clk);
		moter_rpm.min1_motor_revolution = (moter_rpm.sec1_motor_revolution * 60);
		moter_rpm.motor_rpm = (moter_rpm.min1_motor_revolution / Motor_gear);
		return moter_rpm.motor_rpm;
	}
	
	return 0;
}