/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : packet.c
* Last version	: 1.00
* Description	: This file is source file for packet receive, transmit function
*
* History
* Date		    Version	    Author			Description
* 04/06/2010	1.00	    oh woomin	    created
*****************************************************************************/

/* Includes ----------------------------------------------------------------*/
#include "stm32_uart.h"
#include "Packet.h"
#include "led.h"

/* Privated defines --------------------------------------------------------*/
#define LF				    0x0A
#define CR				    0x0D


void PacketInit(ReceivePacket *packet)
{
    packet->BufferCount = 0;
    packet->complete = 0;
    packet->start = 0;
}

/*****************************************************************************
* Descriptions  : Get receive packet
* Parameters    : UART port, Receive packet
* Return Value  : Error Status(SUCCESS, ERROR)
*****************************************************************************/
int BluePacket(ReceivePacket *packet)
{
    char RcvChar;
    
    if(UART1_getchar(&RcvChar) == 0) return 0;  
    
    // ��Ŷ ���۹��� ����
    if(RcvChar == '$')
    {
        
        packet->BufferCount = 0;
        packet->complete = 0;
        packet->start = 1;       
        
    }
    
    // ��Ŷ ���Ṯ�� ����
    else if((packet->buffer[packet->BufferCount-1] == CR) && (RcvChar == LF))
    {
     
        if(packet->start)
        {
            packet->complete = 1;
            packet->start = 0;
        }
        else return 0;
    }
    
    // Frame Data ����
    else
    {
        if(packet->start)
        {
            packet->buffer[packet->BufferCount++] = RcvChar;
        }
        else return 0;
    }    
    
    return 1;
}

int OscillPacket(ReceivePacket *packet)
{
    char RcvChar;
    
    if(UART3_getchar(&RcvChar) == 0) return 0;  
     //UART4_printf("%c" ,RcvChar);
    
    // ��Ŷ ���۹��� ����
    if(RcvChar == '$')
    {
        
        packet->BufferCount = 0;
        packet->complete = 0;
        packet->start = 1;       
        
    }
    
    // ��Ŷ ���Ṯ�� ����
    else if((packet->buffer[packet->BufferCount-1] == CR) && (RcvChar == LF))
    {
     
        if(packet->start)
        {
            packet->complete = 1;
            packet->start = 0;
        }
        else return 0;
    }
    
    // Frame Data ����
    else
    {
        if(packet->start)
        {
            packet->buffer[packet->BufferCount++] = RcvChar;
        }
        else return 0;
    }    
    
    return 1;
}

