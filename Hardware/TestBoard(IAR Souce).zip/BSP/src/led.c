/*****************************************************************************
* Copyright(C) 2013 Dong-A University MICCA_25th-GoJiSeong
* All right reserved.
*
* File name	    : led.c
* Last version	: 1.00
* Description	: This file contains definitions for STM32E_Module led_port resources
*
* History
* Date		    Version	    Author			Description
* 01/11/2013	1.00		oh woomin	    Created
*****************************************************************************/
#include "stm32f4xx.h"
#include "stm32f4xx_it.h"
#include "led.h"

void LED_init(void)
{
    GPIO_InitTypeDef GPIO_ledset;
    
    RCC_AHB1PeriphClockCmd(LED_periph,ENABLE);
    
    GPIO_ledset.GPIO_Pin = LED1_pin | LED2_pin |LED3_pin;
    GPIO_ledset.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_ledset.GPIO_OType = GPIO_OType_PP;
    GPIO_ledset.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_ledset.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(LED_port, &GPIO_ledset);
    
    LED1_off(); LED2_off(); LED3_off();
}

void LH_init(void)
{
    GPIO_InitTypeDef GPIO_lhset;
    
    RCC_AHB1PeriphClockCmd(LH_periph,ENABLE);
    
    GPIO_lhset.GPIO_Pin = LH1_pin | LH2_pin;
    GPIO_lhset.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_lhset.GPIO_OType = GPIO_OType_PP;
    GPIO_lhset.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_lhset.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(LH_port, &GPIO_lhset);
    
    LH1_off(); LH2_off();
}