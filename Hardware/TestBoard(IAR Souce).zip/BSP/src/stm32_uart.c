/*****************************************************************************
* Copyright(C) 2011 Dong-A University MICCA
* All right reserved.
*
* File name	    : stm32_uart.c
* Last version	: 2.00
* Description	: This file is source file for uart function.
*
* History
* Date		    Version	    Author			Description
* 03/06/2011	2.00		oh woomin	    ver2.0 create
*****************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <stdarg.h>
#include <stdio.h>
#include "stm32f4xx.h"
#include "stm32_uart.h"
#include "queue.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
QueueType Uart1RxQueue, Uart2RxQueue, Uart4RxQueue , Uart3RxQueue;
QueueType Uart1TxQueue, Uart2TxQueue, Uart4TxQueue , Uart3TxQueue;

/* Private function prototypes -----------------------------------------------*/
#ifdef __GNUC__
  /* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
     set to 'Yes') calls __io_putchar() */
  #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
  #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */

/*****************************************************************************
* Descriptions  : Retargets the C library printf function to the USART.
* Parameters    : None
* Return Value  : None
*****************************************************************************/
PUTCHAR_PROTOTYPE
{
	if (ch == '\n')
    {
        USART_SendData(USART1, '\r');
        /* Loop until the end of transmission */
        while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);        
    }
    USART_SendData(USART1, (uint8_t) ch);    
    /* Loop until the end of transmission */
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);    
       
    return ch;
}

/*****************************************************************************
* Descriptions  : Initialize the UART port.
* Parameters    : Port, Baudrate
* Return Value  : None
*****************************************************************************/
void UART_init(u8 uart, u32 baud)
{
    USART_InitTypeDef USART_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure; 
    NVIC_InitTypeDef NVIC_InitStructure;   
    
    if(uart == 1)
    {   
        /* Enable USART1 clock */
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
        /* Enable GPIO clock */        
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);         
                            
        /* Connect PXx to USART1_Tx*/
        GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_USART1);        
        /* Connect PXx to USART1_Rx*/
        GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_USART1);
        
        /* Enable the USART1 Interrupt */
        NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
        NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;    
        NVIC_Init(&NVIC_InitStructure);          
        
        /* Configure USART1 Tx as alternate function  */
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
        
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        
        /* Configure USART1 Rx as alternate function  */
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
        GPIO_Init(GPIOB, &GPIO_InitStructure);                                        
    }
    else if(uart == 2)
    {   
        /* Enable USART1 clock */
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
        /* Enable GPIO clock */        
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);         
                            
        /* Connect PXx to USART1_Tx*/
        GPIO_PinAFConfig(GPIOD, GPIO_PinSource5, GPIO_AF_USART2);        
        /* Connect PXx to USART1_Rx*/
        GPIO_PinAFConfig(GPIOD, GPIO_PinSource6, GPIO_AF_USART2);
        
        /* Enable the USART2 Interrupt */
        NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
        NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;    
        NVIC_Init(&NVIC_InitStructure);          
        
        /* Configure USART2 Tx as alternate function  */
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
        
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(GPIOD, &GPIO_InitStructure);
        
        /* Configure USART2 Rx as alternate function  */
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
        GPIO_Init(GPIOD, &GPIO_InitStructure);                                        
    }    
    else if(uart == 3)
    { 
        /* Enable USART1 clock */
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
        /* Enable GPIO clock */        
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);         
                            
        /* Connect PXx to USART1_Tx*/
        GPIO_PinAFConfig(GPIOD, GPIO_PinSource8, GPIO_AF_USART3);        
        /* Connect PXx to USART1_Rx*/
        GPIO_PinAFConfig(GPIOD, GPIO_PinSource9, GPIO_AF_USART3);
        
        /* Enable the USART2 Interrupt */
        NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
        NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;    
        NVIC_Init(&NVIC_InitStructure); 
        
        /* Configure USART1 Tx as alternate function  */
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
        
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(GPIOD, &GPIO_InitStructure);
        
        /* Configure USART1 Rx as alternate function  */
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
        GPIO_Init(GPIOD, &GPIO_InitStructure);          
    }
    else if(uart == 4)
    {
        /* Enable USART1 clock */
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);
        /* Enable GPIO clock */        
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);         
                            
        /* Connect PXx to USART1_Tx*/
        GPIO_PinAFConfig(GPIOC, GPIO_PinSource10, GPIO_AF_UART4);        
        /* Connect PXx to USART1_Rx*/
        GPIO_PinAFConfig(GPIOC, GPIO_PinSource11, GPIO_AF_UART4);
        
        /* Enable the USART1 Interrupt */
        NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
        NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;    
        NVIC_Init(&NVIC_InitStructure);            
        
        /* Configure USART1 Tx as alternate function  */
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
        
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(GPIOC, &GPIO_InitStructure);
        
        /* Configure USART1 Rx as alternate function  */
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
        GPIO_Init(GPIOC, &GPIO_InitStructure);          
    }   
    /* 
        USARTx configured as follow:
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
    */    
    USART_InitStructure.USART_BaudRate = baud;                                      
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;                    
    USART_InitStructure.USART_StopBits = USART_StopBits_1;                          
    USART_InitStructure.USART_Parity = USART_Parity_No;                             
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;                 
    
    if(uart == 1)
    {   
        /* Configure USART1 */             
        USART_Init(USART1, &USART_InitStructure);
        /* Enable the USART1 */              
        USART_Cmd(USART1, ENABLE);	
        /* Enable USART1 Receive interrupt */
        USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);            
    }
    else if(uart == 2)
    {   
        /* Configure USART2 */             
        USART_Init(USART2, &USART_InitStructure);
        /* Enable the USART2 */              
        USART_Cmd(USART2, ENABLE);	  
        /* Enable USART2 Receive interrupt */
        USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);           
    }    
    else if(uart == 3)
    {                           
        /* Configure USART1 */             
        USART_Init(USART3, &USART_InitStructure);
        /* Enable the USART1 */              
        USART_Cmd(USART3, ENABLE);
        /* Enable USART2 Receive interrupt */
        USART_ITConfig(USART3, USART_IT_RXNE, ENABLE); 
    }
    else if(uart == 4)
    {                           
        /* Configure USART4 */             
        USART_Init(UART4, &USART_InitStructure);
        /* Enable the USART4 */              
        USART_Cmd(UART4, ENABLE);	             
        /* Enable USART4 Receive interrupt */
        USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);                  
    }      
}

/*****************************************************************************
* Descriptions  : UART1���� 1���� ���
* Parameters    : 1byte ����(ascii code)
* Return Value  : ���� ���� ��ȯ (SUCCESS, ERROR)
*****************************************************************************/
ErrorStatus UART1_putchar(char ch)
{    
	if (ch == '\n')
    {
        if(enqueue(&Uart1TxQueue, '\r') != QUEUE_SUCCESS)
        {            
            return ERROR;        
        }                       
    }    
    if(enqueue(&Uart1TxQueue, ch) != QUEUE_SUCCESS)
    {            
        return ERROR;        
    }               
    USART_ITConfig(USART1, USART_IT_TXE, ENABLE);
    
    return SUCCESS;            
}
/*****************************************************************************
* Descriptions  : UART1���� ���Ź��ۿ��� 1���� ��������
* Parameters    : ��ȯ�� ����
* Return Value  : ���� ���� ��ȯ(SUCCESS, ERROR)
*****************************************************************************/
ErrorStatus UART1_getchar(char *ascii)
{          
    if(dequeue(&Uart1RxQueue, (unsigned char *)ascii) == QUEUE_SUCCESS) 
        return SUCCESS;
    else 
        return ERROR;
}

/*****************************************************************************
* Descriptions  : UART1���� ���ڿ� ���
* Parameters    : ����� ���ڿ�
* Return Value  : None
*****************************************************************************/
void UART1_putstr(char *string)
{
	while(*string != '\0') 
        UART1_putchar(*(string++));
}

/*****************************************************************************
* Descriptions  : UART1���� printf ���
* Parameters    : printf ����
* Return Value  : None
*****************************************************************************/
void UART1_printf(const char *fmt,...)
{
	char string[256];
	va_list ap;

	va_start(ap,fmt);
	vsprintf(string,fmt,ap);
	va_end(ap);

	UART1_putstr(string);
}

/*****************************************************************************
* Descriptions  : UART2���� 1���� ���
* Parameters    : 1byte ����(ascii code)
* Return Value  : ���� ���� ��ȯ (SUCCESS, ERROR)
*****************************************************************************/
ErrorStatus UART2_putchar(char ch)
{    
	if (ch == '\n')
    {
        if(enqueue(&Uart2TxQueue, '\r') != QUEUE_SUCCESS)
        {            
            return ERROR;        
        }                       
    }    
    if(enqueue(&Uart2TxQueue, ch) != QUEUE_SUCCESS)
    {            
        return ERROR;        
    }               
    USART_ITConfig(USART2, USART_IT_TXE, ENABLE);
    
    return SUCCESS;            
}

/*****************************************************************************
* Descriptions  : UART2�� ���Ź��ۿ��� 1���� ��������
* Parameters    : ��ȯ�� ����
* Return Value  : ���� ���� ��ȯ(SUCCESS, ERROR)
*****************************************************************************/
ErrorStatus UART2_getchar(char *ascii)
{          
    if(dequeue(&Uart2RxQueue, (unsigned char *)ascii) == QUEUE_SUCCESS) 
        return SUCCESS;
    else 
        return ERROR;
}

/*****************************************************************************
* Descriptions  : UART2�� ���ڿ� ���
* Parameters    : ����� ���ڿ�
* Return Value  : None
*****************************************************************************/
void UART2_putstr(char *string)
{
	while(*string != '\0') 
        UART2_putchar(*(string++));
}

/*****************************************************************************
* Descriptions  : UART1�� printf ���
* Parameters    : printf ����
* Return Value  : None
*****************************************************************************/
void UART2_printf(const char *fmt,...)
{
	char string[256];
	va_list ap;

	va_start(ap,fmt);
	vsprintf(string,fmt,ap);
	va_end(ap);

	UART2_putstr(string);
}

/*****************************************************************************
* Descriptions  : UART4���� 1���� ���
* Parameters    : 1byte ����(ascii code)
* Return Value  : ���� ���� ��ȯ (SUCCESS, ERROR)
*****************************************************************************/
ErrorStatus UART4_putchar(char ch)
{    
	if (ch == '\n')
    {
        if(enqueue(&Uart4TxQueue, '\r') != QUEUE_SUCCESS)
        {            
            return ERROR;        
        }                       
    }       
    if(enqueue(&Uart4TxQueue, ch) != QUEUE_SUCCESS)
    {            
        return ERROR;        
    }               
    USART_ITConfig(UART4, USART_IT_TXE, ENABLE);
    
    return SUCCESS;            
}

/*****************************************************************************
* Descriptions  : UART4���� ���Ź��ۿ��� 1���� ��������
* Parameters    : ��ȯ ����
* Return Value  : ���� ���� ��ȯ(SUCCESS, ERROR)
*****************************************************************************/
ErrorStatus UART4_getchar(char *ch)
{          
    if(dequeue(&Uart4RxQueue, (unsigned char *)ch) == QUEUE_SUCCESS) 
        return SUCCESS;
    else 
        return ERROR;
}

/*****************************************************************************
* Descriptions  : UART4���� ���ڿ� ���
* Parameters    : ����� ���ڿ�
* Return Value  : None
*****************************************************************************/
void UART4_putstr(const char *string)
{
	while(*string != '\0') 
        UART4_putchar(*(string++));
}

/*****************************************************************************
* Descriptions  : UART4�� printf ���
* Parameters    : printf ����
* Return Value  : None
*****************************************************************************/
void UART4_printf(const char *fmt,...)
{
	char string[256];
	va_list ap;

	va_start(ap,fmt);
	vsprintf(string,fmt,ap);
	va_end(ap);

	UART4_putstr(string);
}

/*****************************************************************************
* Descriptions  : UART3���� 3���� ���
* Parameters    : 1byte ����(ascii code)
* Return Value  : ���� ���� ��ȯ (SUCCESS, ERROR)
*****************************************************************************/
ErrorStatus UART3_putchar(char ch)
{    
	if (ch == '\n')
    {
        if(enqueue(&Uart3TxQueue, '\r') != QUEUE_SUCCESS)
        {            
            return ERROR;        
        }                       
    }    
    if(enqueue(&Uart3TxQueue, ch) != QUEUE_SUCCESS)
    {            
        return ERROR;        
    }               
    USART_ITConfig(USART3, USART_IT_TXE, ENABLE);
    
    return SUCCESS;            
}
/*****************************************************************************
* Descriptions  : UART3���� ���Ź��ۿ��� 1���� ��������
* Parameters    : ��ȯ�� ����
* Return Value  : ���� ���� ��ȯ(SUCCESS, ERROR)
*****************************************************************************/
ErrorStatus UART3_getchar(char *ascii)
{          
    if(dequeue(&Uart3RxQueue, (unsigned char *)ascii) == QUEUE_SUCCESS) 
        return SUCCESS;
    else 
        return ERROR;
}

/*****************************************************************************
* Descriptions  : UART3���� ���ڿ� ���
* Parameters    : ����� ���ڿ�
* Return Value  : None
*****************************************************************************/
void UART3_putstr(char *string)
{
  int i;
	for(i=0;i<150;i++)
	{
	  UART3_putchar(*(string++));
	}
}

/*****************************************************************************
* Descriptions  : UART3���� printf ���
* Parameters    : printf ����
* Return Value  : None
*****************************************************************************/
void UART3_printf(const char *fmt,...)
{
	char string[256];
	va_list ap;

	va_start(ap,fmt);
	vsprintf(string,fmt,ap);
	va_end(ap);

	UART3_putstr(string);
}
