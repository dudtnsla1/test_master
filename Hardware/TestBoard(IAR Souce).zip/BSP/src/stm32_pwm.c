#include "stm32f4xx.h"
#include "stm32_pwm.h"

static __IO uint16_t Timer1Period, Timer8Period, Timer5Period ,Timer3Period;
static __IO uint16_t Timer5Prescaler,Timer3Prescaler;

void PWM_timer5_port_init(void)
{  
    GPIO_InitTypeDef GPIO_pwm_init;
    
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    
    GPIO_pwm_init.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_pwm_init.GPIO_Mode = GPIO_Mode_AF;
    GPIO_pwm_init.GPIO_OType = GPIO_OType_PP;
    GPIO_pwm_init.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_pwm_init.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOA, &GPIO_pwm_init);
    
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource0, GPIO_AF_TIM5);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource1, GPIO_AF_TIM5);

    
}

void PWM_timer5_init(int frequency)
{
    
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_OCInitTypeDef  TIM_OCInitStructure;
    
    PWM_timer5_port_init();
    Timer5Prescaler = (uint16_t) ((SystemCoreClock/2) / 21000000) - 1;
    Timer5Period = (uint16_t) (21000000 / frequency) - 1;
    
    /* TIM5 clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5 , ENABLE);   
    
    /* Time Base configuration */
    TIM_TimeBaseStructure.TIM_Prescaler = Timer5Prescaler;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_Period = Timer5Period;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;    
    TIM_TimeBaseInit(TIM5, &TIM_TimeBaseStructure);
            
    /* Channel 1, 2, 3 and 4 Configuration in PWM mode */
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; 
    TIM_OC1Init(TIM5, &TIM_OCInitStructure);
    
    TIM_OC1PreloadConfig(TIM5, TIM_OCPreload_Enable);
    
    TIM_ARRPreloadConfig(TIM5, ENABLE);
    
    /* TIM5 counter enable */
    TIM_Cmd(TIM5, ENABLE);   
}

void PWM_timer5_output(int ch, int value)
{   
    TIM_OCInitTypeDef  TIM_OCInitStructure;
    uint16_t pulse = (uint16_t) (((uint32_t) value * Timer5Period) / 1000);   
 
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = pulse;    
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    
    if(ch == 1) TIM_OC1Init(TIM5, &TIM_OCInitStructure);            
    else if(ch == 2) TIM_OC2Init(TIM5, &TIM_OCInitStructure);            
    else if(ch == 3) TIM_OC3Init(TIM5, &TIM_OCInitStructure);            
    else if(ch == 4) TIM_OC4Init(TIM5, &TIM_OCInitStructure); 
           
}

void PWM_timer3_port_init(void)
{  
    GPIO_InitTypeDef GPIO_pwm_init;
    
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
    
    GPIO_pwm_init.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_pwm_init.GPIO_Mode = GPIO_Mode_AF;
    GPIO_pwm_init.GPIO_OType = GPIO_OType_PP;
    GPIO_pwm_init.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_pwm_init.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOC, &GPIO_pwm_init);
    
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource6, GPIO_AF_TIM3);
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource7, GPIO_AF_TIM3);
}

void PWM_timer3_init(int frequency)
{
    
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_OCInitTypeDef  TIM_OCInitStructure;
    
    PWM_timer3_port_init();
    Timer3Prescaler = (uint16_t) ((SystemCoreClock/2) / 21000000) - 1;
    Timer3Period = (uint16_t) (21000000 / frequency) - 1;
    
    /* TIM5 clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3 , ENABLE);   
    
    /* Time Base configuration */
    TIM_TimeBaseStructure.TIM_Prescaler = Timer3Prescaler;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_Period = Timer3Period;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;    
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
            
    /* Channel 1, 2, 3 and 4 Configuration in PWM mode */
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; 
    TIM_OC1Init(TIM3, &TIM_OCInitStructure);
    
    TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable);
    
    TIM_ARRPreloadConfig(TIM3, ENABLE);
    
    /* TIM5 counter enable */
    TIM_Cmd(TIM3, ENABLE);   
}

void PWM_timer3_output(int ch, int value)
{   
    TIM_OCInitTypeDef  TIM_OCInitStructure;
    uint16_t pulse = (uint16_t) (((uint32_t) value * Timer3Period) / 1000);   
 
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = pulse;    
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    
    if(ch == 1) TIM_OC1Init(TIM3, &TIM_OCInitStructure);            
    else if(ch == 2) TIM_OC2Init(TIM3, &TIM_OCInitStructure);            
    else if(ch == 3) TIM_OC3Init(TIM3, &TIM_OCInitStructure);            
    else if(ch == 4) TIM_OC4Init(TIM3, &TIM_OCInitStructure); 
           
}

void PWM_timer1_port_init(void)
{  
    GPIO_InitTypeDef GPIO_pwm_init;
    
    /* GPIOE Clocks enable */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);
    
    /* GPIOE Configuration: Channel 9, 11, 13 and 14 as alternate function push-pull */
    GPIO_pwm_init.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14;
    GPIO_pwm_init.GPIO_Mode = GPIO_Mode_AF;
    GPIO_pwm_init.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_pwm_init.GPIO_OType = GPIO_OType_PP;
    GPIO_pwm_init.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOE, &GPIO_pwm_init);
    
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource13, GPIO_AF_TIM1);
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource14, GPIO_AF_TIM1);
}

void PWM_timer1_init(int frequency)
{
    PWM_timer1_port_init();
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_OCInitTypeDef  TIM_OCInitStructure;    
    
    Timer1Period = (SystemCoreClock / frequency ) - 1;
    
    /* TIM1 clock enable */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1 , ENABLE);    
    
    /* Time Base configuration */
    TIM_TimeBaseStructure.TIM_Prescaler = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_Period = Timer1Period;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);
            
    /* Channel 1, 2, 3 and 4 Configuration in PWM mode */
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
    TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;   
    TIM_OC3Init(TIM1, &TIM_OCInitStructure);
    
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OC4Init(TIM1, &TIM_OCInitStructure);
    
    /* TIM1 counter enable */
    TIM_Cmd(TIM1, ENABLE);
    
    /* TIM1 Main Output Enable */
    TIM_CtrlPWMOutputs(TIM1, ENABLE);      
}

void PWM_timer1_output(int ch, int value)
{   
    TIM_OCInitTypeDef  TIM_OCInitStructure;    
    uint16_t pulse = (uint16_t) (((uint32_t) value * (Timer1Period - 1)) / 1000);    
    
    /* Channel 1, 2, 3 and 4 Configuration in PWM mode */    
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = pulse;    
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
    TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set; 
    
    if(ch == 1) TIM_OC1Init(TIM1, &TIM_OCInitStructure);            
    else if(ch == 2) TIM_OC2Init(TIM1, &TIM_OCInitStructure);            
    else if(ch == 3) TIM_OC3Init(TIM1, &TIM_OCInitStructure);            
    else if(ch == 4) TIM_OC4Init(TIM1, &TIM_OCInitStructure);        
}

void PWM_timer8_port_init(void)
{  
    GPIO_InitTypeDef GPIO_pwm_init;
    
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
    
     /* GPIOC Configuration: Channel 6, 7, 8 and 9 as alternate function push-pull */
    GPIO_pwm_init.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_pwm_init.GPIO_Mode = GPIO_Mode_AF;
    GPIO_pwm_init.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_pwm_init.GPIO_OType = GPIO_OType_PP;
    GPIO_pwm_init.GPIO_PuPd = GPIO_PuPd_UP ;
    GPIO_Init(GPIOC, &GPIO_pwm_init);
    
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource6, GPIO_AF_TIM8);
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource7, GPIO_AF_TIM8);
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource8, GPIO_AF_TIM8);
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource9, GPIO_AF_TIM8);
}

void PWM_timer8_init(int frequency)
{
    PWM_timer8_port_init();
    
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_OCInitTypeDef  TIM_OCInitStructure;
    
    Timer8Period = (SystemCoreClock / frequency) - 1;
    
    /* TIM1 clock enable */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8 , ENABLE); 
    
    /* Time Base configuration */
    TIM_TimeBaseStructure.TIM_Prescaler = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_Period = Timer8Period;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0; 
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    
    TIM_TimeBaseInit(TIM8, &TIM_TimeBaseStructure);
            
    /* Channel 1, 2, 3 and 4 Configuration in PWM mode */
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
    TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;
    
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OC1Init(TIM8, &TIM_OCInitStructure);
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OC2Init(TIM8, &TIM_OCInitStructure);
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OC3Init(TIM8, &TIM_OCInitStructure); 
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OC4Init(TIM8, &TIM_OCInitStructure);
    
    /* TIM1 counter enable */
    TIM_Cmd(TIM8, ENABLE);
    
    /* TIM1 Main Output Enable */
    TIM_CtrlPWMOutputs(TIM8, ENABLE);     
}

void PWM_timer8_output(int ch, int value)
{   
    TIM_OCInitTypeDef  TIM_OCInitStructure;
    uint16_t pulse = (uint16_t) (((uint32_t) value * Timer8Period-1) / 1000);   
 
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = pulse;    
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
    TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set; 
    
    if(ch == 1) TIM_OC1Init(TIM8, &TIM_OCInitStructure);            
    else if(ch == 2) TIM_OC2Init(TIM8, &TIM_OCInitStructure);            
    else if(ch == 3) TIM_OC3Init(TIM8, &TIM_OCInitStructure);            
    else if(ch == 4) TIM_OC4Init(TIM8, &TIM_OCInitStructure); 
           
}