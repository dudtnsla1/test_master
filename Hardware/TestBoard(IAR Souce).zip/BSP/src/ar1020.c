/*****************************************************************************
* Copyright(C) 2013 Dong-A University MICCA
* All right reserved.
*
* File name	    : ar1020.c
* Last version	: V1.00
* Description	: This file is source file for ar1020 driver.
*
* History
* Date		    Version	    Author			Description
* 05/01/2013	1.00		oh woomin	    Created
*****************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "delay.h"
//include "platform_config.h"
//#include "typedef.h"
#include "ar1020.h"

/* Private define ------------------------------------------------------------*/
#define AR1020_TIMEOUT          0xFFFF

void I2C_PortInit(int speed)
{
    I2C_InitTypeDef  I2C_InitStructure; 
    GPIO_InitTypeDef  GPIO_InitStructure; 
             
    /* I2C1 clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);    
    
    /* Configure I2C1 pins: SCL and SDA */    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStructure);    
    
    /* Connect PXx to I2C_SCL*/
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource8, GPIO_AF_I2C1);    
    /* Connect PXx to I2C_SDA*/
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource9, GPIO_AF_I2C1);      
    
    /* I2C configuration */
    I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
    I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
    I2C_InitStructure.I2C_OwnAddress1 = 0x00;
    I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
    I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
    I2C_InitStructure.I2C_ClockSpeed = speed;

    /* I2C Peripheral Enable */
    I2C_Cmd(I2C1, ENABLE);
    /* Apply I2C configuration after enabling it */
    I2C_Init(I2C1, &I2C_InitStructure);                  
}

static void AR1020_PortInit(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;    

    /* Enable AR1020 PENIRQ Pin clocks */
    RCC_APB1PeriphClockCmd(AR1020_IRQ_PERIPH, ENABLE);
    
    // AR1020 PENIRQ �Է��� ����
    GPIO_InitStructure.GPIO_Pin = AR1020_IRQ_BIT;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;    
    GPIO_Init(AR1020_IRQ_PORT, &GPIO_InitStructure);    
}

/*****************************************************************************
* Descriptions  : Initialize the AR1020
* Parameters    : None
* Return Value  : None
*****************************************************************************/
void AR1020_Init(void)
{
    I2C_PortInit(100000);
    AR1020_PortInit();
}

/*****************************************************************************
* Descriptions  : Write the AR1020
* Parameters    : slave addr, number of write, buffer
* Return Value  : error status
*****************************************************************************/
ErrorStatus AR1020_Write(u8 SlaveAddr, int NumByteToWrite, u8 *buffer)
{
    uint32_t timeout = AR1020_TIMEOUT;
    int i;
    
    /* Generate the Start Condition */
    I2C_GenerateSTART(I2C1, ENABLE);
    
    /* Test on I2C1 EV5 and clear it */
    timeout = AR1020_TIMEOUT; /* Initialize timeout value */
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT))
    {
        /* If the timeout delay is exeeded, exit with error code */
        if ((timeout--) == 0) return ERROR;
    }
    
    /* Send DCMI selcted device slave Address for write */
    I2C_Send7bitAddress(I2C1, SlaveAddr, I2C_Direction_Transmitter);
    
    /* Test on I2C1 EV6 and clear it */
    timeout = AR1020_TIMEOUT; /* Initialize timeout value */
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
    {
        /* If the timeout delay is exeeded, exit with error code */
        if ((timeout--) == 0) return ERROR;
    }
        
    for(i=0; i<NumByteToWrite; i++)
    {            
        /* Send Data */
        I2C_SendData(I2C1, (uint8_t)buffer[i]);
        
        /* Test on I2C1 EV8 and clear it */
        timeout = AR1020_TIMEOUT; /* Initialize timeout value */
        while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED))
        {
            /* If the timeout delay is exeeded, exit with error code */
            if ((timeout--) == 0) return ERROR;
        }  
    }
    
    delay_us(50);    
    /* Send I2C1 STOP Condition */
    I2C_GenerateSTOP(I2C1, ENABLE);
    
    /* If operation is OK, return 0 */
    return SUCCESS;    
}

/*****************************************************************************
* Descriptions  : Read the AR1020
* Parameters    : slave addr, number of write, buffer
* Return Value  : error status
*****************************************************************************/
ErrorStatus AR1020_Read(u8 SlaveAddr, int NumByteToRead, u8 *buffer)
{
    uint32_t timeout = AR1020_TIMEOUT;
    int i;
    
    /* Enable Acknowledgement */
    I2C_AcknowledgeConfig(I2C1, ENABLE);  
    
    /* Generate the Start Condition */
    I2C_GenerateSTART(I2C1, ENABLE);
    
    /* Test on I2C1 EV5 and clear it */
    timeout = AR1020_TIMEOUT; /* Initialize timeout value */
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT))
    {
        /* If the timeout delay is exeeded, exit with error code */
        if ((timeout--) == 0) return ERROR;
    } 
        
    /* Send DCMI selcted device slave Address for write */
    I2C_Send7bitAddress(I2C1, SlaveAddr, I2C_Direction_Receiver);
    
    /* Test on EV6 and clear it */
    timeout = AR1020_TIMEOUT; /* Initialize timeout value */    
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED))
    {
        /* If the timeout delay is exeeded, exit with error code */
        if ((timeout--) == 0) return ERROR;        
    }
        
    for(i=0; i<NumByteToRead; i++)
    {        
        if(i == NumByteToRead - 1)
        {
            /* Disable Acknowledgement */
            I2C_AcknowledgeConfig(I2C1, DISABLE); 
            /* Send STOP Condition */
            I2C_GenerateSTOP(I2C1, ENABLE);      
        }            
        /* Test on EV7 and clear it */
        timeout = AR1020_TIMEOUT; /* Initialize timeout value */        
        while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_RECEIVED))
        {
            /* If the timeout delay is exeeded, exit with error code */
            if ((timeout--) == 0) return ERROR;
        }
        /* Store received data on I2C1 */
        *buffer = I2C_ReceiveData(I2C1);
        buffer++;
    }
    
    return SUCCESS;
}

int i2c_read(u8 addr, u8 reg, u8 *data)
{
    int Timeout;    
    
    /* Enable Acknowledgement */
    I2C_AcknowledgeConfig(I2C1,ENABLE);
    
   /* Send START condition */
    I2C_GenerateSTART(I2C1, ENABLE);  
    /* Test on EV5 and clear it */
    Timeout = 0xFFFF;
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT))
    {
        if(Timeout-- == 0) return 0;
    }
    
    /* Send slave address for write */
    I2C_Send7bitAddress(I2C1, addr, I2C_Direction_Transmitter);
    /* Test on EV6 and clear it */
    Timeout = 0xFFFF;
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
    {
        if(Timeout-- == 0) return 0;
    }

    
    /* Send the internal address to write to */    
    I2C_SendData(I2C1, reg);
    /* Test on EV8 and clear it */
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED));    
    
    
    /* Send STRAT condition a second time */  
    I2C_GenerateSTART(I2C1, ENABLE);
    /* Test on EV5 and clear it */
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT));    
    
    /* Send device address for read */
    I2C_Send7bitAddress(I2C1, addr, I2C_Direction_Receiver);
    /* Test on EV6 and clear it */
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED));
    
    /* Test on EV7 and clear it */
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_RECEIVED));  
    /* Store received data on I2C1 */
    *data = I2C_ReceiveData(I2C1);            
    /* Disable Acknowledgement */
    I2C_AcknowledgeConfig(I2C1, DISABLE); 
    /* Send STOP Condition */
    I2C_GenerateSTOP(I2C1, ENABLE);   
    
    delay_us(100);
    
    return 1;     
    
}

